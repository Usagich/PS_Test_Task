﻿Configuration Alesia_File_Task
{

    param(
 	[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$path,

 	[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$fileName,

 	[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$fileContent
    )
    
    Import-DscResource -ModuleName PsDesiredStateConfiguration

    
        WindowsFeature NetFramework
        {
            Ensure = "Present" 
            Name = "NET-Framework-45-Core"
        }
        File FileContent 
        {
            Ensure = "Present"
            DestinationPath = $path + $fileName
            Contents = $fileContent
        }
        Log LoggingForCopy
        {
            Message = "Trying to put variables"
            DependsOn = "[File]FileContent"
        }

}
